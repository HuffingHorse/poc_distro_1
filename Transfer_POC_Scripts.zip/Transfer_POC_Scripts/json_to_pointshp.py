import json
import geopandas as gpd
from shapely.geometry import Point
import sys

with open(r"C:\Python\geo_convert\flight_data\flight_frames_v2.json", "r") as f:
    data = json.load(f)

geometries = []
flights = []
missions = []
callsigns = []
categories = []

for entry in data:
    flight = entry.get("Flight")
    mission = entry.get("Mission")
    callsign = entry.get("Callsign")
    category = entry.get("category")
    coords = entry.get("Coordinates")

    for i in range(0, len(coords), 2):
        lon = coords[i]
        lat = coords[i + 1]
        geometries.append(Point(lon, lat))
        flights.append(flight)
        missions.append(mission)
        callsigns.append(callsign)
        categories.append(category)

gdf = gpd.GeoDataFrame({
    "Flight": flights,
    "Mission": missions,
    "Callsign": callsigns,
    "Category": categories,
    "geometry": geometries
}, crs="EPSG:4326")


gdf.to_file(r"C:\Python\geo_convert\shapefiles\flight_points.shp")

print("Shapefile created successfully!")
