import json
import os

base_dir = r"C:\Python\geo_convert"
flight_data_dir = os.path.join(base_dir, "flight_data")
output_dir = os.path.join(base_dir, "flight_geography\\test_out")
os.makedirs(output_dir, exist_ok=True)

for filename in os.listdir(flight_data_dir):
    if filename.endswith(".json"):
        json_path = os.path.join(flight_data_dir, filename)
        with open(json_path, "r") as f:
            data = json.load(f)

        sql_statements = []

        for entry in data:
            flight = entry.get("Flight")
            callsign = entry.get("Callsign")
            mission = entry.get("Mission")
            category = entry.get("Category")
            coords = entry.get("Coordinates")
            timestamp = entry.get("Timestamp")

            # Loop through coordinate pairs
            for i in range(0, len(coords), 2):
                lon = coords[i]
                lat = coords[i + 1]

                sql = f"""
INSERT INTO FlightFrames 
(Flight, Callsign, Mission, Category, Latitude, Longitude, Timestamp)
VALUES ({flight}, '{callsign}', '{mission}', '{category}', {lat}, {lon}, '{timestamp}');
"""
                sql_statements.append(sql.strip() + "\n")

        # Write SQL to output file
        output_file = os.path.join(output_dir, os.path.splitext(filename)[0] + "_geography.sql")
        with open(output_file, "w") as f_out:
            f_out.writelines(sql_statements)

        print("Generated", output_file)
    