from flask import Flask, render_template, request
import pyodbc
import webbrowser

app = Flask(__name__)

# SQL Server connection
conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=FlightDB;" 
    "Trusted_Connection=yes;"
)

def run_query(query, params=()):
    with pyodbc.connect(conn_str) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchall()

@app.route('/')
def index():
    return render_template('search.html')

@app.route('/search', methods=['POST'])
def search():
    start_time = request.form['start_time']
    end_time = request.form['end_time']
    lat = request.form['lat']
    lon = request.form['lon']
    radius = request.form['radius']

    query = """
        SELECT Flight, Callsign, Mission, Category, Latitude, Longitude, Timestamp
        FROM FlightFrames
        WHERE CAST(Timestamp AS TIME) BETWEEN ? AND ?
    """
    results = run_query(query, (start_time, end_time))

    return render_template('results.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
webbrowser.open("http://127.0.0.1:5000")