import json
import random
import os
from datetime import datetime, timedelta

# Parameters    
start_lon = -122.335167
start_lat = 47.608013
frame_width = 0.005
frame_height = 0.005
num_frames = 100
callsign = "Major"
flight_number = random.randint(20, 99)
mission = "ESRI Image Collect"
category = "ISR Collection"
frames_per_segment = 10

# Output path
output_dir = r"C:\Python\geo_convert\flight_data"
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "flight_major_100frames.json")

# Flight start time
start_time = datetime.strptime("10:30:00", "%H:%M:%S")

# Generate frame data 
frames = []
lon = start_lon
lat = start_lat
direction = 1
segment_counter = 0

for i in range(num_frames):
    frame_coords = [
        round(lon, 6), round(lat, 6),
        round(lon + frame_width, 6), round(lat, 6),
        round(lon + frame_width, 6), round(lat + frame_height, 6),
        round(lon, 6), round(lat + frame_height, 6)
    ]

    frame_time = start_time + timedelta(seconds=i * 6)

    frames.append({
        "Callsign": callsign,
        "Mission": mission,
        "Flight": flight_number,
        "Category": category,
        "Coordinates": frame_coords,
        "Timestamp": frame_time.strftime("%H:%M:%S")
    })

    lon += frame_width * 0.8
    lat += frame_height * 0.6 * direction
    segment_counter += 1

    if segment_counter >= frames_per_segment:
        direction *= -1
        segment_counter = 0

# Write to JSON File
with open(output_path, "w") as f:
    json.dump(frames, f, indent=2)

print(f" Saved 100-frame flight JSON with timestamps to {output_path}")
