import json
import math
import os
from datetime import datetime, timedelta

# Parameters 
start_lon = -122.03218
start_lat = 47.5301
num_frames = 100
frame_width = 0.005
frame_height = 0.005
callsign = "Lake"
flight_number = 14
mission = "ESRI Image Collect"
category = "ISR Collection"

# Output path
output_dir = r"C:\Python\geo_convert\flight_data"
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "flight_lake_100frames_spiral.json")
# Flight start time
start_time = datetime.strptime("10:30:00", "%H:%M:%S")
# Gebnerate frame data
frames = []
radius = 0.0
angle = 0.0
angle_increment = math.radians(15)
radius_increment = 0.002

for i in range(num_frames):
    lon_center = start_lon + radius * math.cos(angle)
    lat_center = start_lat + radius * math.sin(angle)

    frame_coords = [
        round(lon_center, 6), round(lat_center, 6),
        round(lon_center + frame_width, 6), round(lat_center, 6),
        round(lon_center + frame_width, 6), round(lat_center + frame_height, 6),
        round(lon_center, 6), round(lat_center + frame_height, 6)
    ]
    frame_time = start_time + timedelta(seconds=i * 6)
    frames.append({
        "Callsign": callsign,
        "Mission": mission,
        "Flight": flight_number,
        "Category": category,
        "Coordinates": frame_coords,
        "Timestamp": frame_time.strftime("%H:%M:%S")
    })

    angle += angle_increment
    radius += radius_increment

# Save to JSOn
with open(output_path, "w") as f:
    json.dump(frames, f, indent=2)

print(f" Saved {num_frames} JSON to {output_path}")
