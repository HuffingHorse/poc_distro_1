import json
import os
from datetime import datetime, timedelta

#Parameters
start_lon = -122.208
start_lat = 47.685
num_frames = 100
frame_width = 0.005
frame_height = 0.005
callsign = "Edge"
flight_number = 15
mission = "ESRI Image Collect"
category = "ISR Collection"

lon_increment = 0.004 
lat_increment = -0.004

#Output Path
output_dir = r"C:\Python\geo_convert\flight_data"
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "flight_edge_100frames.json")

# Flight start time
start_time = datetime.strptime("10:30:00", "%H:%M:%S")

frames = []
lon = start_lon
lat = start_lat

for i in range(num_frames):
    frame_coords = [
        round(lon, 6), round(lat, 6),
        round(lon + frame_width, 6), round(lat, 6),
        round(lon + frame_width, 6), round(lat + frame_height, 6),
        round(lon, 6), round(lat + frame_height, 6)
    ]
    frame_time = start_time + timedelta(seconds=i * 6)
    
    frames.append({
        "Callsign": callsign,
        "Mission": mission,
        "Flight": flight_number,
        "Category": category,
        "Coordinates": frame_coords,
        "Timestamp": frame_time.strftime("%H:%M:%S")
    })   

    lon += lon_increment
    lat += lat_increment

# Save to JSON
with open(output_path, "w") as f:
    json.dump(frames, f)
print(f" Saved flight JSON to {output_path}")