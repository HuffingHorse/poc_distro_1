Geopandas was downloaded from 

https://geopandas.org/en/stable/

All other modules from

https://pypi.org/project

They remain unedited in their zipped format (as downloaded).