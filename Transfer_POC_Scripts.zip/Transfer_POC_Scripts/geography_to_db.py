import os
import pyodbc

# --- CONFIG ---
base_dir = r"C:\Python\geo_convert"
sql_dir = os.path.join(base_dir, "flight_geography\\test_out")

# SQL Server connection
server = r"AS\SQLEXPRESS"   
database = "FlightDB"  
trusted_connection = "yes"

conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection={trusted_connection};"
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()


for filename in os.listdir(sql_dir):
    if filename.endswith(".sql"):
        sql_path = os.path.join(sql_dir, filename)
        with open(sql_path, "r") as f:
            sql_commands = f.read()
        
        for command in sql_commands.strip().split(";"):
            if command.strip():  
                cursor.execute(command)
        conn.commit()

cursor.close()
conn.close()
print(" All SQL geography files imported into FlightFrames")
