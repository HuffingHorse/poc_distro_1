import json
import geopandas as gpd
from shapely.geometry import Point
import os

# Paths
base_dir = r"C:\Python\geo_convert"
flight_data_dir = os.path.join(base_dir, "flight_data")
output_dir = os.path.join(base_dir, "flight_geography")  # Updated output dir
os.makedirs(output_dir, exist_ok=True)

# Loop through all JSON files
for filename in os.listdir(flight_data_dir):
    if filename.endswith(".json"):
        json_path = os.path.join(flight_data_dir, filename)
        with open(json_path, "r") as f:
            data = json.load(f)

        geometries = []
        flights = []
        callsigns = []
        missions = []
        categories = []
        frame_numbers = []

        for entry in data:
            flight = entry.get("Flight")
            callsign = entry.get("Callsign")
            mission = entry.get("Mission")
            category = entry.get("Category")
            coords = entry.get("Coordinates")

            # Each coordinate pair becomes a point
            for i in range(0, len(coords), 2):
                lon = coords[i]
                lat = coords[i + 1]
                geometries.append(Point(lon, lat))
                flights.append(flight)
                callsigns.append(callsign)
                missions.append(mission)
                categories.append(category)
                frame_numbers.append(i//2 + 1)

        # Create GeoDataFrame
        gdf = gpd.GeoDataFrame({
            "Flight": flights,
            "Callsign": callsigns,
            "Mission": missions,
            "Category": categories,
            "FrameNumber": frame_numbers,
            "geometry": geometries
        }, crs="EPSG:4326")

        # Save as shapefile
        shp_name = os.path.splitext(filename)[0] + "_points.shp"
        shp_path = os.path.join(output_dir, shp_name)
        gdf.to_file(shp_path)
        print(f"Created point shapefile: {shp_name}")
